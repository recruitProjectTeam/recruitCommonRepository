
const rule = {
	'.read': true,
	'.create': true,
	'.delete': true,
	'.update': true
}

module.exports = rule
