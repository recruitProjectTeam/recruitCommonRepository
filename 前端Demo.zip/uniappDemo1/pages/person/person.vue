<template>
	<view class="fa">
		<page-head :title="title"></page-head>
		<view class="sub1">
			<navigator url="../navigate/navigate?title=navigate" hover-class="navigator-hover">
				<button type="default">登录</button>
			</navigator>
			<!-- <button style="pos-bottom: auto;"  tap="openinfo">登录</button> -->
		</view>
		<view class="sub2">
			<navigator url="../../components/sl-filter-master/pages/apposition/index?title=navigate" hover-class="navigator-hover">
				<button type="default">注册</button>
			</navigator>
		</view>
	</view>
</template>

<script>
	// methods: {
	// 	openinfo({
	// 		url: '../info/info?newsid=' + newsid
	// 	})
	// }
	export default{
		data(){
			return {
				title:'navigate'
			}
		}
	}
</script>

<style>
	.sub1 {
		position: absolute;
		left: 140px;
		top: 500rpx;
		border: 0px solid black;
		padding: 0px;
		text-align: center;
	}

	.sub2 {
		position: absolute;
		left: 230px;
		top: 500rpx;
		/* width: 500rpx; */
		/* height: 10000rpx; */
		border: 0px solid black;
		padding: 0px;
		text-align: center;
	}
</style>
