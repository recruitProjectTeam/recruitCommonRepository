<template>
	<view>
		<!-- <uni-nav-bar left-icon="back" left-text="返回" right-text="菜单" title="导航栏组件"></uni-nav-bar> -->
		<!-- <page-head :title="title" style="height: 1000rpx;"></page-head> -->
		<view class="uni-common-mt">
			<view class="uni-form-item uni-column">
				<view class="title">可自动聚焦的input
					<input class="uni-input" focus placeholder="自动获得焦点" />
				</view>
				
				<view class="title">控制最大输入长度的input</view>
				<input class="uni-input" maxlength="10" placeholder="最大输入长度为10" />
				<view class="title">密码输入的input</view>
				<input class="uni-input" password type="text" placeholder="这是一个密码输入框" />
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				title: '新建的页面'
			}
		}
	}
</script>

<style>
</style>
