<template>
	<view style="color: #555555;">
		<view class="active" style="position: absolute;left: 6%;top: 2%;">
		<!-- @change用于获取下拉框改变的值，:range用于循环遍历array数组将数组内容循环
			循环array数组index为索引
		-->
		<picker @change="bindPickerChange" :range="array,array2">
				<label :readonly="disable"><b>推荐</b></label>
				<label style="position:relative;left: 5%;">地区</label>
				<label class="" style="position:relative;left: 10%;color: #0079FF;">{{array[index]}}</label>
				<label style="position:relative;left: 15%;">筛选</label>	
				<label class="" style="position:relative;left: 20%;color: #0079FF;">{{array2[index2]}}</label>
		</picker>
		</view>
		<!-- <view class="content">
		        <sl-filter :themeColor="themeColor" :mezzzznuList="menuList" @result="result"></sl-filter>
		</view> -->
		<list>
		    <!-- 注意事项: 不能使用 index 作为 key 的唯一标识 -->
		    <cell v-for="(item, index) in dataList" :key="item.id">
			  <view data-v-2c4ec07a="" class="link_rect" :style="'position: absolute;themeColor:#eeee; width: 96%; height: 25%; left: 2%;top:'+item.tes">
				  <text><b>{{item.name}}</b></text>
				  <text style="position: absolute;right: 3%;color: #4CD964;"><b>{{item.salary}}</b></text>
				  <view style="position: relative;top: 5%;">
					<view>
						<text style="color: #4CD964;">{{item.company}}</text>
						<text style="font-size: 28rpx;position: relative;left: 3%;">{{item.profession}}</text>
						<text style="font-size: 28rpx;position: relative;left: 6%;color: #555555;">{{item.people}}</text>
						<text type="tag" style="position: absolute;right: 3%;color: #009696;">{{item.year}}</text>
					</view>
					<view class="example-body" style="position: relative;top: 20%;">
						<view class="tag-view">
							<uni-tag text="Springboot" style="padding: 1rpx;line-height: initial;height: inherit;font-size: 3rpx;"/>
						</view>
						<view class="tag-view">
							<uni-tag text="java高并发" style="padding: 1rpx;line-height: initial;height: inherit;"/>
						</view>
						<view class="tag-view">
							<uni-tag text="html技术" style="padding: 1rpx;line-height: initial;height: inherit;"/>
						</view>
						<view class="tag-view2">
							<uni-tag text="深圳" style="padding: 1rpx;line-height: initial;height: inherit;position: absolute;right: 5%;top: 35%;"/>
						</view>
					</view>
					<view class="example-body">
						<view class="tag-view">
							<uni-tag text="五险一金" style="padding: 1rpx;line-height: initial;height: inherit;font-size: 3rpx;"/>
						</view>
						<view class="tag-view">
							<uni-tag text="年底体检" style="padding: 1rpx;line-height: initial;height: inherit;"/>
						</view>
						<view class="tag-view">
							<uni-tag text="节日福利" style="padding: 1rpx;line-height: initial;height: inherit;"/>
						</view>
						<view class="tag-view">
							<uni-tag text="成长空间大" style="padding: 1rpx;position: relative;left: 3%;line-height: initial;height: inherit;"/>
						</view>
					</view>
				  </view>
			  </view>
			  <view class="colorid" :style="'position: absolute;width: 100%;height: 1.2%;color: #c6c6c6;top:' +item.tops"></view>
		    </cell>
		</list>
	</view>
</template>
	
<script>
	import uniTag from "../../components/uni-tag/uni-tag.vue"
	export default {
		components: {uniTag},
		themeColor: '#000000',
		filterResult: '',
	    data () {
		  return {
				dataList: [
					{id: "1", name: 'JAVA开发工程师',tes:"8%;",company:"平安集团",profession:"保险"
					,people:"300-500人",salary:"15-25K",tops:"30%;",year:"3-5年"},
					{id: "2", name: 'JAVA工程师',tes:"32%;",company:"华为公司",profession:"通讯",people:"500-1000人"
					,salary:"18-25K",tops:"52%;",year:"1-3年"}, 
					{id: "3", name: 'JAVA开发工程师',tes:"54%;",company:"腾讯公司",profession:"互联网",people:"1000-2000人"
					,salary:"20-25K",tops:"74%;",year:"5-8年"},
					{id: "4", name: 'PHP开发工程师',tes:"76%;",company:"波森公司",profession:"贸易",people:"2000-2500人"
					,salary:"20-25K",tops:"96%;",year:"5-10年"},
				],
				array:['请选择','中国','美国'],
				array2:['请选择','深圳','广州'],
				index:0,
				index2:0,
			}
		},
		methods:{
			//下拉框
			bindPickerChange: function(e) {		//改变的事件名
				//console.log('picker发送选择改变，携带值为', e.target.value)   用于输出改变索引值
				this.index = e.target.value			//将数组改变索引赋给定义的index变量
				this.jg=this.array[this.index]		//将array【改变索引】的值赋给定义的jg变量
			//	console.log("籍贯为：",this.jg)		//输出获取的籍贯值，例如：中国
			}
		},
		menuList: [{
				'title': '职位',
				'detailTitle': '请选择职位类型 (可多选)',
				'isMutiple': true,
				'key': 'jobType',
				'detailList': [{
						'title': '不限',
						'value': ''
					},
					{
						'title': 'uni-app',
						'value': 'uni-app'
					},
					{
						'title': 'java 开发',
						'value': 'java'
					},
					{
						'title': 'web 开发',
						'value': 'web'
					},
					{
						'title': 'Android 开发',
						'value': 'Android'
					},
					{
						'title': 'iOS 开发',
						'value': 'iOS'
					}
				]
			},
			{
				'title': '月薪',
				'key': 'salary',
				'isMutiple': true,
				'detailTitle': '请选择月薪范围 (可多选)',
				'detailList': [{
						'title': '不限',
						'value': ''
					},
					{
						'title': '7000~8000',
						'value': '7000~8000'
					},
					{
						'title': '8000~9000',
						'value': '8000~9000'
					},
					{
						'title': '9000~10000',
						'value': '9000~10000'
					},
					{
						'title': '10000 以上',
						'value': '10000~1000000'
					}
				]
			},
			{
				'title': '单选',
				'key': 'single',
				'isMutiple': false,
				'detailTitle': '请选择 (单选)',
				'detailList': [{
						'title': '不限',
						'value': ''
					},
					{
						'title': '条件 1',
						'value': 'test_1'
					},
					{
						'title': '条件 2',
						'value': 'test_2'
					},
					{
						'title': '条件 3',
						'value': 'test_3'
					},
					{
						'title': '条件 4',
						'value': 'test_4'
					},
					{
						'title': '条件 5',
						'value': 'test_5'
					}
				]
			},
			{
				'title': '排序',
				'key': 'sort',
				'isSort': true,
				'detailList': [{
						'title': '默认排序',
						'value': ''
					},
					{
						'title': '发布时间',
						'value': 'add_time'
					},
					{
						'title': '薪资最高',
						'value': 'wages_up'
					},
					{
						'title': '离我最近',
						'value': 'location'
					}
				]
			}
		]
	}
</script>

<style>
	.tets {
		position: absolute;
		width: 96%;
		height: 20%;
		left: 2%;
		top: 20%;
	}
	.example-body {
		flex-direction: row;
		flex-wrap: wrap;
		justify-content: center;
		padding: 1rpx;
		font-size: 5px;
		background-color: #ffffff;
	}
	.example-body {
		flex-direction: column;
		padding: 5px;
		background-color: #ffffff;
	}
	.example-body {
		/* #ifndef APP-PLUS-NVUE */
		display: flex;
		/* #endif */
		flex-direction: row;
		justify-content: flex-start;
		flex-wrap: wrap;
		padding: 0rpx;
	}
	.tag-view {
		/* #ifndef APP-PLUS-NVUE */
		display: flex;
		/* #endif */
		flex-direction: column;
		margin: 2rpx 3rpx;
		justify-content: center;
		padding: 1rpx;
	}
	.colorid{
		position: relative;
		width: 100%;
		height: 1%;
		background-color: #ebebeb;
	}
</style>
